#!/bin/bash

# String provided for analysis
input_string="Hello, World!"

# Count vowels and consonants using 'tr' and 'grep'
vowel_count=$(echo "$input_string" | tr -cd 'AEIOUaeiou' | wc -m)
consonant_count=$(echo "$input_string" | tr -cd 'BCDFGHJKLMNPQRSTVWXYZbcdfghjklmnpqrstvwxyz' | wc -m)

# Output results
echo "String: $input_string"
echo "Vowels: $vowel_count"
echo "Consonants: $consonant_count"

# Add vowel and consonant counts
total_count=$((vowel_count + consonant_count))
echo "Total: $total_count"

