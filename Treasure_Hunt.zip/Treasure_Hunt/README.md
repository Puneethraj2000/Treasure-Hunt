# Treasure_Hunt
You can play this treasure hunt game using your system itself.

# How to play
*>Downlaod the code <br />
*>Open the folder and you will see bunch of folders in it.<br />
*>Also you will see clue text file and clue.pnp file<br />
*>First open clue text file which contains the clue for your treasure hunt<br />
*>Based on the clue you need to solve the puzzle<br />
*>While you solve the puzzle, you will end up in the folder name that you need to open.<br />
*>After you open again you have to check clue text file and it will give the folder name that you need to open<br />
*>Like that you need to recursively open the folders based on the clue.<br />
*>In the final clue it will displays that You are the Winner.<br />

# Rules and Recommendations
*>You have to use only command prompt<br />
*>If you are using ubuntu, use 'shotwell imgname' to open the image.<br />
<br />
# Happy Hunting


