if [ $# -ne 0 ]
then
p=`echo $1 | tr "/" " "`
for i in $p
do
mkdir $i
done
echo "all the directories are created"
else
echo " please enter a parameter"
fi
